package mvc;

public class CommandProcessor {
    public static void execute(Command cmmd){
    cmmd.execute();
    }
}