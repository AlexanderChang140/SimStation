package SimStation;

public enum AgentState {
    READY, RUNNING, PAUSED, STOPPED
}
